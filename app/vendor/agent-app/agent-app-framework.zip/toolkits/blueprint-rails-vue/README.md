# blueprint-rails-vue

A Rails + Vue 3 + SQLite Agent App blueprint. `agent-app <dir> scaffold --blueprint blueprint-rails-vue` scaffolds a running to-do app: a Rails server (Puma, no ActiveRecord), a SQLite record store owned by the adapter, a Vue 3 (Vite) View built into `public/`, and a native Ruby A2App adapter — the served surface and pure rules ported to Ruby, with `ruby lib/a2app_adapter.rb --selftest` as the parity check. Built from [../blueprint-base/](../blueprint-base/); vendors the reference [kit](../kit/)'s token sheet. Not part of the pnpm workspace (Ruby + a nested npm project).

Layout:

| Path | Ownership | Role |
|---|---|---|
| `config/application.rb`, `config/routes.rb`, `config/puma.rb` | system-owned (hash-locked) | the minimal Rails app: action_controller only, one catch-all route into the controller, the adapter's Host check in front of every path, request bodies never parsed or logged by Rails, loopback bind, headless boot (no credentials ritual) |
| `app/controllers/a2app_controller.rb` | system-owned (hash-locked) | the wiring: Rack request → `adapter.dispatch()`, 5 MiB body cap, every error in the protocol's envelope, and everything else served as the View (`public/`, the watcher, the account page) with ETag validators; identity's `appVersion` fingerprint |
| `lib/a2app_adapter.rb` | system-owned (hash-locked) | the served surface (protocol 0.2: accounts, credentials, device sign-in, the user ceiling) + pure rules (parity with `@a2app/rules`) + the SQLite store, where records and all adapter state persist (tasks, events, approvals, idempotency keys, audit) + the View's static server + `--selftest` |
| `a2app-update.js` | system-owned (hash-locked) | the View's update watcher, served at `/_a2app/update.js` |
| `a2app-account.html` | system-owned (hash-locked) | the framework's account page (sign in, invites, people, connected agents), served at `/_a2app/account`; the same file in every blueprint |
| `lib/a2app_schema.rb` | agent-owned | the data model + operations — edit this to evolve the app; `describe`/`schemaVersion` derive from it |
| `ui/` | agent-owned | the human View: a Vue 3 app compiled by `vite build` into `public/` (git-ignored build output — never hand-edited) |
| `ui/public/` | agent-owned | assets copied through the build verbatim — the kit token sheet (`tokens.css`) and component styles (`ui.css`) |
| `manifest.json`, `operations.json`, `AGENT_APP.md`, `reference/requirements.md` | framework files | identity, declared ops, plan, requirements |
| `.a2app/system-hashes.json` | ownership canon | which files are system-owned |

The agent operates the app through A2App; a human uses the same data through the View. Both see each other's writes on the next read.

## Keeping an open tab honest

The View is served from a build on disk, so a promote is live server-side the moment the app restarts — but a browser tab opened beforehand is still running the JavaScript it downloaded, and nothing about that is visible to the person looking at it.

Two system-owned pieces close that, and neither needs anything from the app author:

- **The View is served with `Cache-Control: no-cache` and an ETag** (the adapter's `StaticView`, called by the controller; Rails' own static file server is off). A plain reload always revalidates and gets changed files; an unchanged file costs a bodyless 304.
- **`a2app-update.js`, served at `/_a2app/update.js` beside the View,** polls identity's `appVersion` — a content fingerprint of the served View (`public/**` + the schema + the watcher and the account page), which moves for changes `schemaVersion` is blind to — and reloads (or offers a reload) when the code the tab is running has been superseded.

The View loads the watcher through one runtime import; keep it when you rewrite the View:

```js
// ui/src/updater.js — a runtime import Vite must not try to bundle
const watcher = import(/* @vite-ignore */ "/_a2app/update.js").catch(() => null);
```

It **reloads only when the page holds nothing unsaved**, and otherwise offers a dismissible banner. These are data-entry apps: discarding half-typed input is worse than the stale tab it would be curing. The person is told, and chooses.
