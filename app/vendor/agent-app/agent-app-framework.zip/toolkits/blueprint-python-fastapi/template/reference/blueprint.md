# Blueprint reference — python-fastapi

A FastAPI backend + a SQLite store, whose A2App adapter is a dependency-free,
in-process Python port of the served surface (identity, describe, guarded
records CRUD, operations with approval, tasks/events, accounts and agent
credentials). Records persist in SQLite via the stdlib `sqlite3` module. The
pure rules match `@a2app/rules` byte-for-byte on rejections — the conformance
suite is the oracle.

Where the `creator`/`modify` skill says "per your stack", the answer is here. If
this file and the source disagree, the source wins.

## Read this first

The scaffold gives you a complete, agent-operable backend — the A2App adapter and
a working data model. A human View is out of scope for this stack:

- **entities** — the data model in `schema.py` (see **Schema** below);
- **custom operations** — declared in `schema.OPERATIONS` + `operations.json` and
  implemented in `schema.OPERATION_RUNNERS` (see **Operations**);
- **the View** — this stack serves the A2App API only; `main.py` (system-owned)
  exposes `/api/**`, `/.well-known/a2app.json` and the framework's account page
  (`/_a2app/account`, which `/` leads to), so it cannot present a browser UI of
  its own.

Use this stack when an agent is the operator. If you need a human web UI, choose
`blueprint-react-node` or `blueprint-pocketbase-react` — decide before building.

## File map — who owns what

Every file that ships on a fresh scaffold, in the order you meet them:

| Path | Owner | What it is |
|---|---|---|
| `schema.py` | **YOURS** | the data model + operations: `ENTITIES`, `OPERATIONS`, `OPERATION_RUNNERS`, `EVENTS`, `SEED`. Edit this to evolve the app; `describe`/`schemaVersion` derive from it. |
| `operations.json` | **YOURS** | the operation declarations `describe` and approval read (name, module, typed params, entity, appliesWhen, flags). Mirror of `schema.OPERATIONS`. |
| `AGENT_APP.md` | **YOURS** | this app's index: plan, modules, entities, operations, conventions, checklist. |
| `reference/requirements.md` | **YOURS** | the binding spec — Part A (SRS) + Part B (tech spec + Quality Conformance). |
| `reference/tasks.md` | **YOURS** | the build ledger — one task per feature/quality item, ticked as you complete it. |
| `reference/blueprint.md` | reference | this file — the stack map. |
| `.gitignore` | **YOURS** | ignores `data/`, credentials, framework state, `__pycache__`. Extend as needed. |
| `requirements.txt` | build | Python dependencies. Add your HTTP client (e.g. `httpx`) here when you call external APIs. |
| `manifest.json` | SYSTEM (hash-locked) | app identity, `modules[]`, `authMode`, `pipeline` (install/build/start/health). |
| `main.py` | SYSTEM (hash-locked) | FastAPI wiring: every request meets the adapter first (body read under a size cap, Host checked on every path) and `adapter.dispatch()` answers `/api/_a2app/**`, `/api/collections/**`, `/api/ops/**` and `/.well-known/a2app.json`; serves the account page. Never edit. |
| `a2app_adapter.py` | SYSTEM (hash-locked) | the adapter — served surface (identity, describe, guarded CRUD, operations, tasks/events, accounts, credentials, device sign-in) + the pure rules (guard, predicates, fingerprint) + the SQLite store + `--selftest`. Never edit. |
| `a2app-account.html` | SYSTEM (hash-locked) | the framework's account page at `/_a2app/account`: sign in, accept an invite, people (owner), the agents acting for you. The same file in every blueprint. Never edit. |
| `scripts/promote_apply.py` | lifecycle | run by `agent-app promote`: applies to live after a mandatory backup; refuses to orphan an entity that still holds data. Leave it alone. |
| `data/` | runtime | the live SQLite database (`db.sqlite`, git-ignored, created on first boot): records, and the adapter's own state in tables of its own (credentials, accounts, tasks, events, approvals, idempotency keys, the audit log), all of which survive a restart. Never edit by hand; never commit. |

SYSTEM files are hashed in `.a2app/system-hashes.json`; the gate fails the build
if one changes.

## Mental model

- The **adapter is the only agent surface.** `main.py` reads HTTP and calls
  `adapter.dispatch()`; the adapter owns the protocol.
- **`schema.py` is the single source of truth for the model.** You never
  hand-write `describe` — the adapter derives it (and `schemaVersion`) from
  `ENTITIES`/`OPERATIONS`. Change the schema, and every A2App screen updates.
- **The model is declarative and additive.** Records are JSON rows in one
  SQLite table keyed (entity, id); there are no migration files on this stack.
  Add a field to `ENTITIES` and it is simply available; existing rows keep
  their stored values. Do not look for a `migrations/` directory.

## Schema — entities & fields

Edit `schema.py`. Three module-level names drive the app:

```python
ENTITIES = {
    "<entity>": {
        "module": "<module-from-manifest>",   # REQUIRED — every entity names its module
        "summary": "one line shown beside it on the module screen",
        "fields": [
            {"name": "title", "type": "string", "required": True, "max": 200},
            {"name": "status", "type": "enum", "values": ["todo", "doing", "done"]},
            {"name": "due", "type": "string", "max": 10, "dayKey": True},   # "YYYY-MM-DD"
            {"name": "created", "type": "datetime", "readOnly": True},       # server-set
            {"name": "owner", "type": "string", "readOnly": True},           # who created it
        ],
        "ownedBy": "owner",   # see **Accounts and whose records** below
    },
}

SEED = {"<entity>": [{"id": "…", "title": "…", "created": "2026-01-01T00:00:00Z"}]}
```

**Field types** (the A2App protocol vocabulary): `string` · `number` · `boolean`
· `datetime` · `enum` (+ `values`) · `ref` (+ `entity`) · `list<enum>` ·
`list<ref>` · `json` · `binary`. Field flags: `required`, `readOnly`
(server-managed), `max`, and `dayKey: True` for a whole-day text field advertised
as `YYYY-MM-DD`.

**Seeding:** `SEED` is applied only when a boot CREATES the database file
(first live boot; every `dev` boot, since dev runs against a fresh per-boot
data directory). An existing database is never re-seeded — that would
resurrect seed records the user deleted.

## Operations — anything beyond plain CRUD

Plain CRUD needs no operation — the records API covers it. Declare an operation
in **two places that must agree**, then implement it:

1. `schema.OPERATIONS` — and the identical row in `operations.json`.
2. `schema.OPERATION_RUNNERS` — a `name -> function` map.

```python
OPERATIONS = [
    {"name": "clear-done", "description": "Delete every done task.",
     "destructive": True, "module": "planning", "params": {}},
    {"name": "complete-task", "description": "Mark one task done.",
     "module": "planning", "entity": "tasks",
     "appliesWhen": {"field": "status", "ne": "done"},
     "params": {"task": {"type": "ref", "entity": "tasks", "required": True}}},
]

def _clear_done(args, ctx, store):
    removed = 0
    for rec in store.list_records("tasks", {})["items"]:
        if rec.get("status") == "done" and store.delete_record("tasks", rec["id"]):
            removed += 1
    return {"removed": removed}

def _complete_task(args, ctx, store):
    task = store.get_record("tasks", args.get("task"))
    if task is None:
        return {"ok": False, "reason": "no such task"}
    task["status"] = "done"
    store.put_record("tasks", task)
    return {"ok": True, "task": task["id"], "status": task["status"]}

OPERATION_RUNNERS = {"clear-done": _clear_done, "complete-task": _complete_task}
```

- **Runner signature:** `(args, ctx, store) -> json-able dict`. `ctx` is who is
  calling (`{"credentialId", "agentName", "principal", "role"}`). `store` is the
  live SQLite-backed store — read with `store.get_record(entity, id)` /
  `store.list_records(entity, query)`, write with `store.put_record(entity,
  record)` / `store.delete_record(entity, id)`. Writes are durable when the
  call returns. A record read from the store is a COPY: mutate it, then
  `put_record()` it back, or the change never happened.
- **`params` is REQUIRED and typed** (same vocabulary as fields); use `{}` for
  none. The record screen renders it as the signature, and the adapter guards
  the arguments by it before your runner sees them: a missing required
  parameter, an undeclared one, or a value outside a declared enum is refused
  `400`, exactly as a record write would be. A required `ref` to the record's
  own entity is named on the record screen as its `targetParam`.
- **Refusing.** A runner that cannot do what was asked raises
  `OperationError(code, message, status=400, extra=None)` (from
  `a2app_adapter`): the caller gets that status and `{code, message, …extra}`.
  Any other exception is a `500 operation_failed`.
- **`entity`** attaches the op to a record screen; **`appliesWhen`** decides
  availability on a record and the adapter derives the blocked reason from it.
  Comparisons only — `eq`, `ne`, `in`, `notIn`, `isBlank`, composed with
  `all`/`any`/`not`. Never a natural-language rule.
- **Flags:** `destructive: True` (requires human approval: the first call
  answers `428` with an `approvalKey` for that exact call, good once and for
  10 minutes), `readOnly: True` (no side effects), `idempotent: True` (safe to
  repeat). A caller's `Idempotency-Key` makes any call run once (`409
  duplicate_request` on a replay, for 24 hours).
- The gate step **"operations resolve"** fails the build if any op in
  `OPERATIONS` has no entry in `OPERATION_RUNNERS`.

## The records API (what the adapter serves)

The adapter serves the A2App records REST under `/api/`, dispatched from
`main.py`'s catch-all:

| Call | Meaning |
|---|---|
| `GET /api/collections/<entity>/records?filter=…&sort=…&page=…&perPage=…` | list (single-clause filter: `field = "v"` · `field != "v"` · `field ~ "v"`; anything richer is refused `invalid_filter`, never ignored) |
| `POST /api/collections/<entity>/records` (JSON body) | create (guard validates the raw body) |
| `PATCH /api/collections/<entity>/records/<id>` | update |
| `DELETE /api/collections/<entity>/records/<id>` | delete |
| `GET /api/_a2app` and `/api/_a2app/describe/**` | identity + describe |

Agent requests carry a credential (`X-A2App-Token`). On `authMode: none`,
same-origin browser requests are trusted by the adapter's origin rule
(`allowed_origins` in `main.py`); on `multi-user`, a browser request carries
the person's session instead.

## External data (third-party APIs)

Call the internet from the **backend only**. Your backend seam is the
**operation runner** — runners execute in-process and may make outbound HTTP
(e.g. `httpx`/`urllib`). Put third-party calls and secret-bearing requests there;
model an initial sync as a runner that fills the store when it is empty. Add the
HTTP client to `requirements.txt`.

## App→agent (tasks/events)

**This blueprint supports them.** An operation runner reaches the queue through
the `store` it is handed, and the event types it may fire are declared in
`schema.py`:

```python
EVENTS = [{"type": "invoice.needs_review"}]   # schema.py — every type a runner fires

def _request_review(args, ctx, store):
    rec = store.get_record("invoices", args.get("invoice"))
    fired = store.trigger("invoice.needs_review", {"invoice": rec["id"]}, capability="review")
    return {"ok": True, "queued": fired["taskId"]}
```

`store.trigger(etype, payload, capability=None)` emits the event and, when a
capability is named, puts a task on the app's queue; it returns
`{"eventId": ..., "taskId": ...}`. Without a capability it only announces
something — nothing is queued and no agent is handed it. The starter's
`request-triage` operation is the worked example.

- **Declare the type in `EVENTS` first.** A type that is not declared is
  refused at the moment of firing — inside the operation, in front of a user.
- **Firing the same occurrence twice makes one task.** The same type,
  capability, payload and caller return the task already queued rather than a
  second, while that task is open. Once it is completed, failed or canceled, the
  same trigger queues a new one, so asking again needs nothing special. Tasks,
  events and the event cursor survive a restart, and a task id is never reused.
- **Send ids, not prose or copies.** The agent re-reads the record itself, so a
  copy is stale by the time it is read, and prose in a payload is an instruction
  the app does not get to give: on the agent's side it is fenced and labelled as
  data.
- **The agent acts as whoever asked.** The task records the runner's caller
  (the `store` a runner is handed binds it to `trigger`), and the bridge runs the
  agent with a credential for that person: it sees and changes only what they
  could, and dies when the task ends. Say what the work needs in `CAPABILITIES`
  in `schema.py` — `{"triage": {"scopes": ["data:tasks:read",
  "data:tasks:write"]}}` — and the credential holds no more; a capability left
  out gets `*`, still within that person's reach.
- There is **no declarative trigger manifest**, and none is coming — what the
  agent does is the agent's decision, which is what keeps a compromised app from
  steering it. Do not invent a manifest format.
- Prefer plain code for plain events. A task is for work a person would
  otherwise have to think about, and it must be idempotent: a task can be
  redelivered if an agent dies holding it.

The queue only moves when something is listening: `agent-app <dir> bridge start`,
or a harness polling `a2app <dir> tasks next --wait`.

**Show the queued work in the View.** Keep the returned `taskId` on the record
and follow it from the UI with a same-origin `GET /api/_a2app/tasks/{id}`, polled
only while it is unfinished. That read needs no credential: on a single-user app
the app's own page is trusted, and on a multi-user app the person's session
makes it — a person reaches the tasks they asked for, and an owner every task.
A 404 means the task has been pruned (or was never theirs), so drop the
indicator. Don't retry it. Render
queued → working (`progress.step`) → done or failed (`reason`, plus a way to ask
again). The creator skill lists the states. A button that goes quiet after it
queues work looks broken.

## Accounts and whose records (`authMode: multi-user`)

Scaffold with `--auth-mode multi-user` for an app with accounts. The adapter
then holds the accounts and sessions itself, in tables of its own in
`data/db.sqlite` — they are never records:

- **Signing in** happens on the framework's account page, `/_a2app/account`,
  which `main.py` serves (and `/` leads to, as this stack has no View of its
  own). A request from the app's own page with no session answers
  `401 sign_in_required` with the page's `signInUrl`; a program without a
  credential gets `agent_token_required`.
- **The first owner** comes from `agent-app <dir> owner`, which prints a
  one-time setup link. Owners invite everyone else from the account page (or
  `agent-app <dir> invite`). Nobody's password passes through the CLI or an
  agent.
- **Whose records.** `"ownedBy": "<field>"` on an entity names a `readOnly`
  string field the adapter fills with the creator's principal. A member then
  lists, reads, changes and deletes only its own records (anyone else's answer
  404); an owner sees all. The starter's `tasks` is owned by `owner`.
- **Runners** get the caller as `ctx = {"principal", "role", …}` and must hold
  themselves to the same rule for records they touch — the starter's `_mine`
  helper in `schema.py` is the pattern.

On `authMode: none` the same code runs with one principal, `owner`: every
record is the owner's and nothing is filtered.

## Reaching the app from another machine

The app listens on loopback and answers only to its own names. To let people and
agents reach it from elsewhere, tell it the address they will use, with
`A2APP_PUBLIC_URL`:

- **Behind a TLS proxy (recommended).** Keep the default bind (`A2APP_HOST`
  unset: loopback), put a proxy that terminates TLS in front, and serve with the
  public address. With Caddy, which keeps the original `Host`:

      crm.example.com {
          reverse_proxy 127.0.0.1:<port>
      }

      A2APP_PUBLIC_URL=https://crm.example.com agent-app <dir> serve

  An agent elsewhere then operates it as `a2app https://crm.example.com`, with
  a credential the owner gives it.
- **Through an SSH tunnel.** Nothing to configure: `ssh -L 9000:127.0.0.1:<port>
  <host>`, then `a2app http://localhost:9000`. The tunnel ends on loopback, and
  carries the token encrypted.
- **Listening on the network directly** (`A2APP_HOST=0.0.0.0`) needs an `https`
  `A2APP_PUBLIC_URL`; otherwise the app refuses to start, because the agent
  token would cross the network in clear. A plain-`http` public URL is refused
  for the same reason unless it names this machine (a tunnel).

A request under any other host name is refused `403 forbidden_host`: the app
answers only to loopback and the host of `A2APP_PUBLIC_URL`. That refusal is
also what stops a page whose DNS re-resolves to 127.0.0.1 from reading the app.

**Embedding.** The app's pages may be shown in a frame by the app itself and by
agent harness pages on the viewer's own machine (`http://127.0.0.1:*`,
`http://localhost:*`), sent as `Content-Security-Policy: frame-ancestors`. Set
`A2APP_FRAME_ANCESTORS` to name the embedders instead — space- or comma-separated
http(s) origins, `*.` subdomain and `*` port wildcards allowed (like
`https://portal.example.com`) — or `none` for the app alone; an entry that is
not an origin refuses to start. Behind an https `A2APP_PUBLIC_URL` the session
cookie is `SameSite=None; Secure; Partitioned`, so a person can stay signed in
to the app inside the harness page (that sign-in belongs to that page alone).

## Build, run, gate

`manifest.json`'s `pipeline` drives everything; the app runs as `python main.py`,
whose `__main__` block binds uvicorn to the environment's `PORT`. Never start a
server by hand. (The start command reads `PORT` from the environment rather than
interpolating `${PORT}` in the shell, so it is portable to cmd.exe on Windows.)

```bash
agent-app <dir> dev        # boot the candidate on a hidden port: fresh per-boot SQLite store re-seeded from empty, prints the dev URL
agent-app <dir> validate   # framework files → build → python syntax + adapter self-test → operations resolve → ownership canon → describe budget (on dev)
agent-app <dir> serve      # launch LIVE as a managed, health-polled background process; prints the URL
agent-app <dir> promote    # requires the gate pass; backup, scripts/promote_apply.py, destroys the dev instance
```

**Environments (one tree, redirected inputs).** `main.py` reads `PORT` and
`A2APP_DATA_DIR` from the framework. The dev instance runs against a
disposable per-boot SQLite database (a fresh directory means a fresh file
means a fresh seed); the LIVE database lives in `data/db.sqlite` — what
`backup`, `restore` and the mandatory pre-promote backup protect.

Toolkit gate steps (from `a2app.toolkit.json`): **"python syntax + adapter
self-test"** (`python -m py_compile … && python a2app_adapter.py --selftest` —
the selftest covers the rules parity against vectors from the reference, the
served surface end to end, AND the SQLite store: every table durable across a
reopen, seed-once, key expiry, the filter grammar) and **"operations
resolve"**. `lifecycle.dataDir` is `data/`; `lifecycle.promote` is
`python scripts/promote_apply.py`.

## Footguns for this stack

- **Two files, one truth.** Every operation lives in BOTH `schema.OPERATIONS` and
  `operations.json`, agreeing on name/module/params/flags. The gate fails a
  mismatch.
- **`put_record()` or it never happened.** A record read from the store is a
  copy; a runner that mutates it without `store.put_record()` returns success
  while storing nothing.
- **Schema is declarative; the UI seam is closed.** Evolve the model by editing
  `ENTITIES` — there is no `migrations/` directory to look for. `main.py` serves
  only the API and the account page, so this stack cannot present a browser UI
  of its own; build one on
  `blueprint-react-node` or `blueprint-pocketbase-react` instead. See **Read this
  first** above.
- **Empty-store first responses.** A fresh app has no records — describe and any
  load path must succeed against an empty store.
